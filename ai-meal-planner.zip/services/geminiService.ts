
import { GoogleGenAI, Type } from "@google/genai";
import { UserInputs, MealPlanResponse, DayPlan } from "../types";

const MEAL_PLAN_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    plan: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          day: { type: Type.INTEGER },
          breakfast: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              summary: { type: Type.STRING }
            },
            required: ["title", "summary"]
          },
          lunch: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              summary: { type: Type.STRING }
            },
            required: ["title", "summary"]
          },
          dinner: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              summary: { type: Type.STRING }
            },
            required: ["title", "summary"]
          }
        },
        required: ["day", "breakfast", "lunch", "dinner"]
      }
    },
    shoppingList: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          item: { type: Type.STRING },
          category: { type: Type.STRING }
        },
        required: ["item", "category"]
      }
    }
  },
  required: ["plan", "shoppingList"]
};

// Generate a 7-day meal plan using gemini-3-pro-preview
export const generateMealPlan = async (inputs: UserInputs): Promise<MealPlanResponse> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  let batchCookingInstruction = "";
  if (inputs.batchCooking) {
    batchCookingInstruction = `
      IMPORTANT: This is a BATCH COOKING plan. 
      1. Design the plan so that major cooking only happens TWICE per week (e.g., Day 1 and Day 4).
      2. Meals on other days should be leftovers, recombinations, or simple assembly of items prepared in the two big cooking sessions.
      3. Focus on high ingredient reuse across different meals to minimize waste and preparation time.
      4. Explicitly mention in the summaries which items were prepared beforehand.
    `;
  }

  const prompt = `
    Generate a 7-day meal plan based on the following preferences:
    Goal: ${inputs.goal}
    Diet: ${inputs.diet}
    Allergies: ${inputs.allergies || 'none'}
    Time per meal: ${inputs.timePerMeal}
    Weekly Budget: ${inputs.budget}
    Existing Ingredients: ${inputs.existingIngredients || 'none'}
    ${batchCookingInstruction}

    Provide a summary for each recipe. Ensure the shopping list is categorized (Produce, Proteins, Dairy, Grains, etc.).
    Avoid ingredients I'm allergic to. Try to use ingredients I already have.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-pro-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: MEAL_PLAN_SCHEMA,
    },
  });

  return JSON.parse(response.text.trim());
};

// Regenerate a specific day using gemini-3-pro-preview
export const regenerateSpecificDay = async (inputs: UserInputs, dayNumber: number, currentPlan: DayPlan[]): Promise<DayPlan> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const prompt = `
    I have an existing 7-day meal plan. I want to replace only Day ${dayNumber}.
    Existing Preferences: Goal: ${inputs.goal}, Diet: ${inputs.diet}, Allergies: ${inputs.allergies || 'none'}.
    Batch Cooking Mode is ${inputs.batchCooking ? 'ON' : 'OFF'}.
    Please provide a new breakfast, lunch, and dinner for Day ${dayNumber} that fits these criteria and integrates well with the rest of the week's theme.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-pro-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          day: { type: Type.INTEGER },
          breakfast: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              summary: { type: Type.STRING }
            },
            required: ["title", "summary"]
          },
          lunch: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              summary: { type: Type.STRING }
            },
            required: ["title", "summary"]
          },
          dinner: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              summary: { type: Type.STRING }
            },
            required: ["title", "summary"]
          }
        },
        required: ["day", "breakfast", "lunch", "dinner"]
      },
    },
  });

  return JSON.parse(response.text.trim());
};
